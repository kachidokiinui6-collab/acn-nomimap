'use client';

type Props = { src?: string };

export default function FormFrame({ src }: Props) {
  const url = src ?? process.env.NEXT_PUBLIC_FORMS_EMBED_SRC ?? '';
  if (!url) {
    return (
      <div className="mx-auto max-w-3xl p-6 text-sm text-red-600">
        フォームのURLが未設定です（NEXT_PUBLIC_FORMS_EMBED_SRC）。
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-3xl w-full p-4">
      {/* 画面の残り高さ = 100svh - ヘッダー高 - 上下パディング等 */}
      <iframe
        title="Submit Form"
        src={url}
        className="w-full rounded-xl shadow border"
        style={{
          // ヘッダー高が layout 側で --header-h に入っていればそれを使用。未設定なら 64px。
          height: 'calc(100svh - var(--header-h, 64px) - 2rem)', // 2rem ≒ p-4 の上下合計
        }}
        loading="lazy"
        frameBorder={0}
        marginHeight={0}
        marginWidth={0}
        referrerPolicy="no-referrer-when-downgrade"
        // 念のため（古ブラウザ向け）。現行では不要だが害もない。
        scrolling="yes"
      />
    </div>
  );
}
